﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function apiProductDetail(message, id, reload) {
    let detail = $.ajax(
        {
            url: `/api/warehouse/${id}`
        }
    ).done(function (r) {
        alert(message + '\n' + JSON.stringify(r, null, ' '));
        if (true == reload) {
            window.location.href = '/test';
        }
    });
}

function apiFullList() {
    let detail = $.ajax(
        {
            url: `/api/warehouse/`
        }
    ).done(function (r) {
        alert(JSON.stringify(r, null, ' '));
    });
}

function apiOrder(productId, available) {
    let quantityReserved = prompt(`Reserve quantity of ${available}?.`);
    let detail = $.ajax(
        {
            type: 'POST',
            url: '/api/warehouse/order',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({ id: productId, quantity: quantityReserved })
        }
    ).done(function (r) {
        apiProductDetail(`Product detail after order ${JSON.stringify(r, null, ' ')}`, productId, true);
    });
}

function apiShip(productId) {
    let quantityShiped = prompt(`Ship quantity?.`);
    let detail = $.ajax(
        {
            type: 'POST',
            url: '/api/warehouse/ship',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({ id: productId, quantity: quantityShiped })
        }
    ).done(function (r) {
        apiProductDetail(`Product detail after ship ${JSON.stringify(r, null, ' ')}`, productId, true);
    });
}

function apiRestock(productId) {
    let quantityUpdated = prompt(`Restock quantity?.`);
    let detail = $.ajax(
        {
            type: 'POST',
            url: '/api/warehouse/restock',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({ id: productId, quantity: quantityUpdated })
        }
    ).done(function (r) {
        apiProductDetail(`Product detail after restock ${JSON.stringify(r, null, ' ')}`, productId, true);
    });
}
