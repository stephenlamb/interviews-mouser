﻿using EPM.Mouser.Interview.Data;
using EPM.Mouser.Interview.Models;
using Microsoft.AspNetCore.Mvc;

namespace EPM.Mouser.Interview.Web.Controllers
{
    [Route("product/{id}")]
    public class ProductController : Controller
    {
        IWarehouseRepository _wareHouseRepository;

        public ProductController(IWarehouseRepository wareHouseRepository)
        {
            _wareHouseRepository = wareHouseRepository;
        }



        [HttpGet]
        public async Task<IActionResult> Index(int id)
        {
            Product product = await _wareHouseRepository.Get(id);
            return View(product);

        }
    }
}