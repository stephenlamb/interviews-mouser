﻿using EPM.Mouser.Interview.Data;
using EPM.Mouser.Interview.Models;
using Microsoft.AspNetCore.Mvc;

namespace EPM.Mouser.Interview.Web.Controllers
{
    [Route("test")]
    public class TestController : Controller
    {
        IWarehouseRepository _wareHouseRepository;



        public TestController(IWarehouseRepository wareHouseRepository)
        { 
            _wareHouseRepository = wareHouseRepository;

        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var products = await _wareHouseRepository.List();
            return View(products);

        }
    }
}